// Chỉ có tracking middleware như booking-ticket-service
import { trackingIn, trackingOut } from './tracking.middleware.ts';

export {
    trackingIn,
    trackingOut
};
