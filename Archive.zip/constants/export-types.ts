export default {
  PAYMENT: {
    BILLS: 'Payment_Bills',
    HISTORY: 'Payment_History',
    REFUND_REQUESTS: 'Refund_Requests'
  },
  WALLET: {
    TRANSACTIONS: 'Wallet_Transactions',
    STATISTICS: 'Wallet_Statistics'
  }
};
