import { createClient } from 'redis';
import crypto from 'crypto';
import SVC_ENV from '../svc-env.ts';
import { ServiceBroker } from 'moleculer';

type RedisClientType = ReturnType<typeof createClient>;

class CacheManager {
  private logger: ServiceBroker['logger'];
  private l1: Map<string, any>;
  private client: RedisClientType | null;
  private ttl: number;
  private prefix: string;

  constructor(logger: ServiceBroker['logger']) {
    this.logger = logger;
    this.l1 = new Map();
    this.client = null;
    this.ttl = Number(SVC_ENV.get().CACHE_TTL_SECONDS || 60);
    this.prefix = 'export:cache:';
  }

  async connect() {
    const cfg = SVC_ENV.get();
    this.client = createClient({ url: `redis://${cfg.REDIS_HOST}:${cfg.REDIS_PORT}` });
    await this.client.connect();
  }

  key(obj: string | object): string {
    const str = typeof obj === 'string' ? obj : JSON.stringify(obj);
    return this.prefix + crypto.createHash('md5').update(str).digest('hex');
  }

  async get(keyObj: string | object): Promise<any | null> {
    const k = this.key(keyObj);
    if (this.l1.has(k)) return this.l1.get(k);
    if (!this.client) return null;
    const v = await this.client.get(k);
    if (v) {
      const parsed = JSON.parse(v);
      this.l1.set(k, parsed);
      return parsed;
    }
    return null;
  }

  async set(keyObj: string | object, val: any): Promise<void> {
    const k = this.key(keyObj);
    this.l1.set(k, val);
    if (this.client) await this.client.setEx(k, this.ttl, JSON.stringify(val));
  }
}

export default CacheManager;
