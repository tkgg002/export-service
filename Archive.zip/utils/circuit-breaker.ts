import { ServiceBroker } from 'moleculer';

class CircuitBreaker {
  private failureCount: number;
  private failureThreshold: number;
  private recoveryTimeout: number;
  private logger: ServiceBroker['logger'] | undefined;
  private state: 'CLOSED' | 'OPEN' | 'HALF_OPEN';
  private lastFailureTime: number;

  constructor({ failureThreshold = 5, recoveryTimeout = 60000, logger }: {
    failureThreshold?: number;
    recoveryTimeout?: number;
    logger?: ServiceBroker['logger'];
  } = {}) {
    this.failureCount = 0;
    this.failureThreshold = failureThreshold;
    this.recoveryTimeout = recoveryTimeout;
    this.logger = logger;
    this.state = 'CLOSED'; // CLOSED, OPEN, HALF_OPEN
    this.lastFailureTime = 0;
  }

  async exec(fn: () => Promise<any>) {
    if (this.state === 'OPEN') {
      const canHalfOpen = Date.now() - this.lastFailureTime > this.recoveryTimeout;
      if (!canHalfOpen) throw new Error('Circuit breaker is OPEN');
      this.state = 'HALF_OPEN';
    }

    try {
      const result = await fn();
      this.onSuccess();
      return result;
    } catch (err: any) {
      this.onFailure(err);
      throw err;
    }
  }

  onSuccess() {
    this.failureCount = 0;
    this.state = 'CLOSED';
  }

  onFailure(err: any) {
    this.failureCount++;
    this.lastFailureTime = Date.now();
    if (this.failureCount >= this.failureThreshold) {
      this.state = 'OPEN';
      if (this.logger) this.logger.warn('Circuit breaker opened: ' + (err?.message || ''));
    }
  }
}

export default CircuitBreaker;
