import BaseExportProcessor from './base-export-processor.ts';

class WalletProcessor extends BaseExportProcessor {
  constructor(options: any) {
    super(options);
  }

  buildFilter(params: any) {
    const filter: any = {};
    if (params.dateFr && params.dateTo) {
      filter.createdAt = {
        $gte: new Date(params.dateFr),
        $lte: new Date(params.dateTo)
      };
    }
    if (params.transType) filter.transType = params.transType;
    if (params.customerId) filter.customerId = params.customerId;
    if (params.status) filter.status = params.status;
    return filter;
  }

  getColumns(langCode: string) {
    return langCode === 'en'
      ? ['Order','Transaction ID','Customer ID','Customer Name','Transaction Type','Amount','Balance Before','Balance After','Status','Date & Time','Description']
      : ['STT','Mã giao dịch','ID khách hàng','Tên khách hàng','Loại giao dịch','Số tiền','Số dư trước','Số dư sau','Trạng thái','Thời gian','Mô tả'];
  }

  createDataProcessor(langCode: string) {
    return (rawData: any[], _lang: string, startIndex = 0) => {
      return rawData.map((item, idx) => ({
        stt: startIndex + idx + 1,
        transactionId: item.trans_id,
        customerId: item.customer_id,
        customerName: item.customer_name,
        transType: item.trans_type,
        amount: this.formatCurrency ? this.formatCurrency(item.amount) : item.amount,
        balanceBefore: this.formatCurrency ? this.formatCurrency(item.balance_before) : item.balance_before,
        balanceAfter: this.formatCurrency ? this.formatCurrency(item.balance_after) : item.balance_after,
        status: item.status,
        dateTime: new Date(item.created_at).toLocaleString('vi-VN'),
        description: item.description || ''
      })).map(item => [
        item.stt, item.transactionId, item.customerId, item.customerName,
        item.transType, item.amount, item.balanceBefore, item.balanceAfter,
        item.status, item.dateTime, item.description
      ]);
    };
  }
}

export default WalletProcessor;
