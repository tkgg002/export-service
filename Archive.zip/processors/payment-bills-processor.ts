import BaseExportProcessor from './base-export-processor.ts';
import _ from 'lodash';

const CHANNELID_LIST = [
  { value: 'VNPAY', label: { vi: 'VNPay', en: 'VNPay' } },
  { value: 'MOMO', label: { vi: 'Momo', en: 'Momo' } },
  { value: 'ZALOPAY', label: { vi: 'ZaloPay', en: 'ZaloPay' } },
  { value: 'WALLET', label: { vi: 'Ví Goopay', en: 'Goopay wallet' } },
  { value: 'GOOPAY_WALLET', label: { vi: 'Ví Goopay', en: 'Goopay wallet' } }
];

class PaymentBillsProcessor extends BaseExportProcessor {
  constructor(options: any) {
    super(options);
  }

  buildFilter(params: any) {
    const filter: any = {};

    if ('merchantId' in params) {
      filter.merchantId = params.merchantId;
    }
    if ('channelID' in params) {
      filter.channelID = params.channelID;
    }
    if ('merchantEmail' in params) {
      filter.merchantEmail = params.merchantEmail;
    }
    if ('apiType' in params) {
      filter.apiType = params.apiType;
    }
    if ('state' in params) {
      filter.state = params.state;
    }
    if ('partnerCode' in params) {
      filter.partnerCode = params.partnerCode;
    }
    if ('orderId' in params) {
      filter.orderId = params.orderId;
    }
    if ('trackingId' in params) {
      filter.trackingId = params.trackingId;
    }
    if ('dateFr' in params || 'dateTo' in params) {
      filter.createdAt = {};
    }
    if ('dateFr' in params) {
      filter.createdAt.$gte = new Date(params.dateFr);
    }
    if ('dateTo' in params) {
      filter.createdAt.$lte = new Date(params.dateTo);
    }
    if ('updatedFr' in params || 'updatedTo' in params) {
      filter.lastUpdatedAt = {};
    }
    if ('updatedFr' in params) {
      filter.lastUpdatedAt.$gte = new Date(params.updatedFr);
    }
    if ('updatedTo' in params) {
      filter.lastUpdatedAt.$lte = new Date(params.updatedTo);
    }
    if ('merchantTransId' in params) {
      filter.merchantTransId = params.merchantTransId;
    }

    filter.isDelete = false;
    return filter;
  }

  getColumns(langCode: string) {
    const cols: Record<string, string[]> = {
      vi: [
        'STT','Tài khoản merchant','Mã giao dịch merchant','Mã đơn hàng',
        'Số tiền','Số tiền thực nhận','Tổng tiền đã hoàn','Thông tin đơn hàng',
        'Kênh thanh toán','Loại API','Loại tiền tệ','Trạng thái','Ngày tạo','Ngày cập nhật'
      ],
      en: [
        'Order','Merchant Account','Merchant Transaction ID','Order ID',
        'Amount','Received Amount','Refunded Amount','Order Information',
        'Payment Channel','API Type','Currency','Status','Created Date','Updated Date'
      ]
    };
    return cols[langCode] || cols.vi;
  }

  createDataProcessor(langCode: string) {
    return (rawData: any[], lang: string, startIndex = 0) => {
      return rawData.map((item, idx) => {
        const channelID = CHANNELID_LIST.find(x => x.value === item.channel_id)?.label[langCode as 'vi' | 'en'] || item.channel_id || '';
        const transformedData = {
          id: startIndex + idx + 1,
          merchantEmail: item.merchant_email,
          merchantTransId: item.merchant_trans_id,
          orderId: item.order_id,
          amount: item.amount,
          paidAmount: item.paid_amount,
          refundedAmount: item.refunded_amount,
          orderInfo: item.order_info,
          channelID,
          apiType: item.api_type || 'REDIRECT',
          currency: item.currency || 'VND',
          state: item.state,
          createdAt: new Date(item.created_at).toLocaleString('en-GB', { timeZone: 'Asia/Ho_Chi_Minh' }),
          lastUpdatedAt: new Date(item.updated_at).toLocaleString('en-GB', { timeZone: 'Asia/Ho_Chi_Minh' })
        };
        return Object.values(transformedData).map(i => i?.toString() || '');
      });
    };
  }

  mappingPaymentChannelName(payments: any[], langCode: string) {
    if (!payments || !Array.isArray(payments)) return '';
    const channelIDs = payments.map(p => p.channelID).filter(Boolean);
    const labels: string[] = [];
    channelIDs.forEach(channelID => {
      const paymentChannel = CHANNELID_LIST.find(x => x.value === channelID);
      if (paymentChannel?.label?.[langCode as 'vi' | 'en']) labels.push(paymentChannel.label[langCode as 'vi' | 'en']);
    });
    return labels.length > 0 ? labels.join('; ') : '';
  }
}

export default PaymentBillsProcessor;
