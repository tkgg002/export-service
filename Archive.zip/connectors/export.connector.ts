import * as storageGateway from './storage-gateway.connector.ts';

export { storageGateway };
