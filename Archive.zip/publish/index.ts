import ExportPublish from './export.publish.ts';
import { ServiceBroker } from 'moleculer';

export const init = ({ logger, exportService, circuitBreaker }: { logger: ServiceBroker['logger'], exportService: any, circuitBreaker: any }) => {
  return {
    exportPublish: new ExportPublish({ logger, exportService, circuitBreaker })
  };
};
