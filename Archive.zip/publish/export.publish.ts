import { Context, ServiceBroker } from 'moleculer';

class ExportPublish {
  private logger: ServiceBroker['logger'];
  private exportService: any;
  private circuitBreaker: any;

  constructor({ logger, exportService, circuitBreaker }: { logger: ServiceBroker['logger'], exportService: any, circuitBreaker: any }) {
    this.logger = logger;
    this.exportService = exportService;
    this.circuitBreaker = circuitBreaker;
  }

  async exportPaymentBills(ctx: Context, progressCallback: Function | null = null) {
    try {
      if (progressCallback && this.exportService?.processors?.['payment-bills']?.setProgressCallback) {
        this.exportService.processors['payment-bills'].setProgressCallback(progressCallback);
      }

      const exec = () => this.exportService.exportData({
        exportType: 'payment-bills',
        params: ctx.params,
        jobId: (ctx.params as any).jobId,
        enableJobTracking: (ctx.params as any).enableJobTracking || false
      });
      return this.circuitBreaker ? await this.circuitBreaker.exec(exec) : await exec();
    } catch (error) {
      this.logger.error('Payment bills export failed:', error);
      throw error;
    }
  }

  async exportWalletTransactions(ctx: Context, progressCallback: Function | null = null) {
    try {
      if (progressCallback && this.exportService?.processors?.['wallet-transactions']?.setProgressCallback) {
        this.exportService.processors['wallet-transactions'].setProgressCallback(progressCallback);
      }

      const exec = () => this.exportService.exportData({
        exportType: 'wallet-transactions',
        params: ctx.params,
        jobId: (ctx.params as any).jobId,
        enableJobTracking: (ctx.params as any).enableJobTracking || false
      });
      return this.circuitBreaker ? await this.circuitBreaker.exec(exec) : await exec();
    } catch (error) {
      this.logger.error('Wallet transactions export failed:', error);
      throw error;
    }
  }
}

export default ExportPublish;
